
from turtle import pd
import mysql.connector
from flask import Flask, Response, request, render_template, redirect, url_for
import matplotlib.pyplot as plt
import seaborn as sns
import io
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import tkinter
tkinter._test()
app = Flask(__name__)





'''

conn = mysql.connector.connect(
    host='localhost',
    user='***',
    password='****',
    database='****'
)


@app.route('/index')
def home():
  
    return render_template('insert.html')



@app.route('/temp', methods=['GET', 'POST'])
def temp():
    if request.method == 'POST':
        temp = request.form['temperatura']
        umid = request.form['umidita']
  
        insert_st = "INSERT INTO TM (temperatura, umidita) VALUES (%s, %s)"
        cursor = conn.cursor()
        cursor.execute(insert_st, (temp, umid))
        conn.commit()
        cursor.close()
        return render_template('insert.html')
    
















if __name__ == '__main__':
    app.run(debug=True)


'''


'''


CREATE TABLE TM (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    temperatura INT,
    umidita INT
);


'''


'''
app = Flask(__name__)





def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='figa86',
        database='db'
    )


@app.route('/index')
def home():
    return render_template('insert.html')

@app.route('/TP')
def temp_md():
    return render_template('Record.html')


@app.route('/temp', methods=['GET', 'POST'])
def temp():
    if request.method == 'POST':
        temp = request.form['temperatura']
        umid = request.form['umidita']
  
        insert_st = "INSERT INTO TM (temperatura, umidita) VALUES (%s, %s)"
        conn = get_db_connection() 
        cursor = conn.cursor()
        cursor.execute(insert_st, (temp, umid))
        conn.commit()
        cursor.close()
        return render_template('insert.html')


@app.route('/TP_record')
def temRecord():
 
        conn = get_db_connection()  
        c = conn.cursor()
        query = "SELECT temperatura, umidita FROM TM;"
        c.execute(query)
        data = c.fetchall()
        c.close()  
        conn.close()  
        return render_template("Record.html", data=data)












if __name__ == '__main__':
    app.run(debug=True)


'''






def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='figa86',
        database='db'
    )



@app.route('/index')
def home():
    return render_template('insert.html')

@app.route('/TP')
def temp_md():
    return render_template('Record.html')



@app.route('/show')  
def show_tem():
    return render_template('grafica.html')





@app.route('/temp', methods=['GET', 'POST'])
def temp():
    if request.method == 'POST':
        temp = request.form['temperatura']
        umid = request.form['umidita']
  
        insert_st = "INSERT INTO TM (temperatura, umidita) VALUES (%s, %s)"
        conn = get_db_connection() 
        cursor = conn.cursor()
        cursor.execute(insert_st, (temp, umid))
        conn.commit()
        cursor.close()
        return render_template('insert.html')








@app.route('/temp_delete', methods=['POST'])
def tempdelete():
    if request.method == 'POST':
        
        id_to_delete = request.form.get('id')  
        delete_st = "DELETE FROM TM WHERE id = %s"
        conn = get_db_connection() 
        cursor = conn.cursor()
        cursor.execute(delete_st, (id_to_delete,))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('temRecord'))







@app.route('/TP_record') 
def temRecord(): #redirect(url_for('temRecord')) from tempdelete()
    conn = get_db_connection()  
    cursor = conn.cursor()
    query = "SELECT id, temperatura, umidita FROM TM;"
    cursor.execute(query)
    data = cursor.fetchall()
    cursor.close()  
    conn.close()  
    return render_template("Record.html", data=data)






app.route('/show') 
def show_tem():
    conn = get_db_connection()
    cursor = conn.cursor()
    query = "SELECT id, temperatura, umidita FROM TM;"
    cursor.execute(query)
    data = cursor.fetchall()
    cursor.close()
    conn.close()

    
    df = pd.DataFrame(data, columns=['id', 'temperatura', 'umidita'])

    x = df['id']
    y_temp = df['temperatura']
    y_hum = df['umidita']

    fig, ax = plt.subplots(figsize=(20, 10))
    
    sns.lineplot(x=x, y=y_temp, ax=ax, label='Temperature', color='blue')
    sns.lineplot(x=x, y=y_hum, ax=ax, label='Humidity', color='green')
    
    ax.set_xlabel('ID')  
    ax.set_ylabel('Value')  
    ax.set_title('Temperature and Humidity over Time')  
    ax.legend()

 
    img = io.BytesIO()
    fig.savefig(img, format='png')
    img.seek(0)
    plt.close(fig)

    
    return Response(img.getvalue(), mimetype='image/png')






if __name__ == '__main__':
    app.run(debug=True)
