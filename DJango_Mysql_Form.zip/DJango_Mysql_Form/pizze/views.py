from django.shortcuts import get_object_or_404, render
from django.shortcuts import render, redirect
from .models import Persona
from pizze.models import Persona
from .forms import PersonaForm
from django.views.decorators.csrf import csrf_exempt
from .models import Persona
# Create your views here.


def index(request):
    return render(request, 'pizze/index.html')





def crea_persona(request):
    if request.method == 'POST':
        form = PersonaForm(request.POST)
        if form.is_valid():
            form.save()  # Salva i dati nel database
             # Reindirizza a una pagina di successo
    else:
        form = PersonaForm()  # Crea una nuova istanza del modulo se la richiesta è GET
    
    # Ritorna il template con il modulo
    return render(request, 'crea_persona.html', {'form': form})

  



def lista_persone(request):
    persone = Persona.objects.all()  # Retrieve all persons from the database
    return render(request, 'lista_persone.html', {'persone': persone})




'''
 #Funzione per cancellare una persona
def cancella_persona(request):
    if request.method == 'POST':
        persona_id = request.POST.get('persona_id')
        if persona_id:
            persona = get_object_or_404(Persona, id=persona_id)
            persona.delete()  # Cancella la persona dal database
            # Reindirizza a una pagina di successo o torna alla lista
            return redirect('lista_persone')  # Assicurati che questa URL esista
    return redirect('lista_persone')  # Se non c'è ID, torna alla lista  


'''



def cancella_persona(request):
    if request.method == 'POST':
        persona_id = request.POST.get('persona_id')  # Get the ID of the persona to delete
        persona = get_object_or_404(Persona, id=persona_id)  # Retrieve the persona or raise a 404 if not found
        persona.delete()  # Delete the persona
        return redirect('pizze:lista_persone')  # Redirect to the list of persons
    return redirect('pizze:lista_persone') 
    