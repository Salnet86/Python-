'''

import subprocess

# Esegui il comando 'top' e prendi l'output
result = subprocess.run(['top', '-b', '-n', '1'], capture_output=True, text=True)
print(result.stdout)


'''

'''
import plotext as plt
import subprocess
import time

# Numero di campioni
samples = 50
cpu_usage = []

for _ in range(samples):
    # Esegui il comando top per ottenere l'utilizzo della CPU
    result = subprocess.run(['top', '-b', '-n', '1'], capture_output=True, text=True)
    
    # Estrai l'utilizzo della CPU dal risultato
    # Cerca la riga con "Cpu(s)"
    for line in result.stdout.splitlines():
        if "Cpu(s)" in line:
            usage = 100 - float(line.split()[1].replace(',', '.'))  # Percentuale di CPU in uso
            cpu_usage.append(usage)
            break
            
    time.sleep(1)  # Aspetta un secondo prima del prossimo campione

# Creazione del grafico
plt.plot(cpu_usage)
plt.title("Utilizzo CPU in tempo reale")
plt.xlabel("Campioni")
plt.ylabel("Utilizzo (%)")
plt.show()
'''



import plotext as plt
import subprocess
import time

# Numero di campioni e intervallo di attesa
samples = 100  # Maggiore numero di campioni
interval = 0.5  # Tempo di attesa in secondi

cpu_usage = []

for _ in range(samples):
    # Esegui il comando top per ottenere l'utilizzo della CPU
    result = subprocess.run(['top', '-b', '-n', '1'], capture_output=True, text=True)
    
    # Estrai l'utilizzo della CPU dal risultato
    for line in result.stdout.splitlines():
        if "Cpu(s)" in line:
            usage = 100 - float(line.split()[1].replace(',', '.'))  # Percentuale di CPU in uso
            cpu_usage.append(usage)
            break
            
    time.sleep(interval)  # Aspetta l'intervallo specificato

# Creazione del grafico
plt.plot(cpu_usage)
plt.title("Utilizzo CPU in tempo reale")
plt.xlabel("Campioni")
plt.ylabel("Utilizzo (%)")
plt.show()

