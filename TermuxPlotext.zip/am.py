import plotext as plt
import math

# Parametri
fs = 100  # Frequenza di campionamento
duration = 1  # Durata in secondi
f_carrier = 5  # Frequenza dell'onda portante
f_signal = 1   # Frequenza del segnale
mod_index = 1  # Indice di modulazione

# Generazione del tempo e delle onde
t = [i / fs for i in range(fs * duration)]
am_wave = []

# Calcolo della modulazione in ampiezza
for time in t:
    signal = 1 + mod_index * math.sin(2 * math.pi * f_signal * time)  # Onda modulante
    am_value = signal * math.cos(2 * math.pi * f_carrier * time)  # Onda AM
    am_wave.append(am_value)

# Creazione del grafico
plt.plot(t, am_wave)
plt.title("Modulazione di Ampiezza (AM)")
plt.xlabel("Tempo (s)")
plt.ylabel("Ampiezza")
plt.show()
