import plotext as plt
import math

# Parametri
fs = 100  # Frequenza di campionamento
duration = 1  # Durata in secondi
f_carrier = 5  # Frequenza dell'onda portante
f_signal = 1   # Frequenza del segnale
mod_index = 2  # Indice di modulazione

# Generazione del tempo e delle onde
t = [i / fs for i in range(fs * duration)]
fm_wave = []

# Calcolo della modulazione in frequenza
for time in t:
    signal = math.sin(2 * math.pi * f_signal * time)
    fm_wave.append(math.cos(2 * math.pi * f_carrier * time + mod_index * signal))

# Creazione del grafico
plt.plot(t, fm_wave)
plt.title("Modulazione di Frequenza (FM)")
plt.xlabel("Tempo (s)")
plt.ylabel("Ampiezza")
plt.show()
