import plotext as plt

# Dati di esempio
x = [1, 2, 3, 4]
y = [10, 15, 7, 10]

# Creazione del grafico
plt.plot(x, y)
plt.title("Esempio di Grafico")
plt.xlabel("X")
plt.ylabel("Y")

# Salva il grafico
plt.savefig('grafico.png')
