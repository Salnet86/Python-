import json

nome=input('Inserci il tuo nome')
eta=int(input('Inserci la tua eta'))
interesse=input('Cosa interessa')
# Un esempio di dizionario Python
data = {
    "nome": nome,
    "età": eta,
    "interessi":interesse
}

# Scrivere il dizionario su un file JSON
with open("dati.json", "w") as file:
    json.dump(data, file, indent=4)  # L'indentazione rende il file più leggibile
