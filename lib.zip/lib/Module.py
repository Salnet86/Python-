def saluto(nome):
    print(f'{nome}')

   

CreatePersone = {
    'nome': 'Martina',
    'cognome': 'Stella',
    'eta': 18,
    'bella': 'Bella donna'
}



def stampa(CreatePersone):
    print(CreatePersone)
