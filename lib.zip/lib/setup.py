from setuptools import setup, find_packages


setup(
    name='persona',
    version='0.1',
    packages=find_packages(),
    install_requires=[],  # Aggiungi qui eventuali dipendenze se necessario
)


