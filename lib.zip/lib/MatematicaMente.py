class FunMate:



    def prodotto(a,b):
        return a*b
