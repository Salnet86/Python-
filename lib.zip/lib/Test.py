3#from Module import saluto
#import Module
#from  MatematicaMente import FunMate as p
from Persona import Persona

#saluto=Module.saluto('Hello')
#saluta=saluto('Ciao bella signora')
#print(saluta)

'''
nome=Module.CreatePersone['nome']
cognome=Module.CreatePersone['cognome']
eta=Module.CreatePersone['eta']
bella=Module.CreatePersone['bella']
p=nome +' '+cognome + ' '+ str(eta) + ' '+bella
Module.stampa(p)
'''


#import os
#print(os.getcwd())
#prodotto=p.prodotto(6,2)
#print(prodotto)
#print(dir(prodotto))
#print(help(prodotto))

p=Persona('Martina','Boxsato')
