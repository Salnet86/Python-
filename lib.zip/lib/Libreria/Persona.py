class Persona:

    def __init__(self, nome, cognome):
        self.nome = nome
        self.cognome = cognome

    def getNome(self):
        return self.nome

    def getCognome(self):
        return self.cognome

