CREATE TABLE TM (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    temperatura INT,
    umidita INT
);