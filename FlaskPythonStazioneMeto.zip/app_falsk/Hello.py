
import io
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from flask import Flask, send_file, render_template
import pandas as pd
import csv





app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")


#Temperatura massima e media
@app.route('/TempMaxMed')
def temperature_Mas_Min():
    df = pd.read_csv('stazione.csv')

    x=df['Temperatura_media']
    y=df['Temperatura_massima']
    fig, ax = plt.subplots(figsize=(20,5))
    #x = [1, 2, 3, 4, 5, 6, 7, 9]
    #y = [12, 13, 14, 16, 20, 22, 25, 27]  # Aggiunta di un valore per "x=9"
    sns.lineplot(x=x, y=y, ax=ax)
    ax.set_title('Temperature massime e minime')
    ax.set_xlabel('Temperatura minima')
    ax.set_ylabel('Temperatura massima')
    canvas = FigureCanvas(fig)
    img = io.BytesIO()
    fig.savefig(img, format='png')
    img.seek(0)
    return send_file(img, mimetype='image/png')




@app.route('/Vento')
def vento():
    df = pd.read_csv('stazione.csv')

    vento=df['Vento Max']
    giorni=df['Giorno']
    fig, ax = plt.subplots(figsize=(20,5))
    sns.lineplot(x=giorni, y=vento, ax=ax)
    ax.set_title('Vento [k/m]')
    ax.set_xlabel('Giorni')
    ax.set_ylabel('Vento max [k/m]')
    canvas = FigureCanvas(fig)
    img = io.BytesIO()
    fig.savefig(img, format='jpg')
    img.seek(0)
    return send_file(img, mimetype='image/jpg')





@app.route('/Mult')
def TempUmidita():
    df = pd.read_csv('stazione.csv')


    umidita=df['Umidità']
    temp_mass=df['Temperatura_massima']

   

    fig, ax = plt.subplots(figsize=(20,5))
    ax.set_title('Temperature [C°]  Umidita')
    ax.set_xlabel('Umidita')
    ax.set_ylabel('Temperature Max[C°]')
    sns.lineplot(x=umidita, y=temp_mass, ax=ax)
    canvas = FigureCanvas(fig)
    img = io.BytesIO()
    fig.savefig(img, format='png')
    img.seek(0)
    return send_file(img, mimetype='image/png')






if __name__ == "__main__":
    app.run(debug=True)