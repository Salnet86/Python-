from flask import Flask, Response, render_template, send_file, jsonify
import io
import psutil
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import pandas as pd

app = Flask(__name__)

@app.route('/index')
def index():
    try:
        cpu_usage = int(psutil.cpu_percent(interval=1))
        disk_usage = int(psutil.disk_usage('/').percent)
        memory_usage = int(psutil.virtual_memory().percent)
      
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    return render_template(
        "index.html",
        cpu=cpu_usage,
        disk=disk_usage,
        memoria=memory_usage,
            
    )

@app.route("/cpu_temperatura")
def CPU_temp():
    return render_template("temperatura.html")








@app.route('/tem')
def temperatura():
    cpu_usages = []
    temperatures = []

    # Collect CPU usage and temperature data
    for _ in range(20):
        cpu_usages.append(psutil.cpu_percent(interval=1))
        temps = psutil.sensors_temperatures()
        
        # Assuming you are interested in the first temperature sensor
        if temps:
            temperatures.append(temps.get('coretemp', [None])[0].current)
        else:
            temperatures.append(None)

    # Check if x and y are equal in length
    if len(cpu_usages) != len(temperatures):
        raise ValueError("CPU usage and temperature lists must be of the same length.")
    
    # Create the plot
    plt.figure(figsize=(20, 5))
    sns.lineplot(x=range(len(cpu_usages)), y=cpu_usages, label='CPU Usage')
    sns.lineplot(x=range(len(temperatures)), y=temperatures, label='Temperature')
    plt.xlabel('Times')
    plt.ylabel('Value')
    plt.title('CPU Usage and Temperature Over Time')
    plt.legend()
    plt.grid(True)
    
    # Save plot to a BytesIO object and return it
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plt.close()
    
    return Response(img, mimetype='image/png')





if __name__ == '__main__':
    app.run(debug=True)
