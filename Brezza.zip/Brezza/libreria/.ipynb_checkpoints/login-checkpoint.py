# login.py
import requests

class Login:
    def RequestsKey(self):
        response = requests.get("https://www.picolab.eu/cgi-bin/python/Client/Send_Client.py")
        return response.text
