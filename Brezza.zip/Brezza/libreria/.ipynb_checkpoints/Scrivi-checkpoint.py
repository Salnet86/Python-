import csv

def WR(lo):
    filename = "DATABASE.csv"
    with open(filename, "a", newline='') as fhand:
        writer = csv.writer(fhand)
        writer.writerow([lo.getNome(), lo.getCognome(), lo.getCF(), lo.getEmail(), lo.getPassword()])
