#Definizione della funzione e attribuzione nome:
def ask():
    '''Funzione che manda una richiesta web al sito www.picolab.eu, riceve in risposta dei dati anagrafici e li stampa a video
    ask()
    >>>('BERNACCI', 'Federica Giusi', 'BRNFGD48L71I319V')
    
       '''
    import requests
    #Utilizzo la funzione get per richiedere dei dati al sito web www.picolab.eu 
    r=requests.get('https://www.picolab.eu/cgi-bin/python/Client/Send_Client.py')
    #Blocco di funzioni che "pulisce" i dati e li salva in delle variabili
    answer=r.text.strip('\n\r')
    dati=answer.split(',')
    dati.pop(0)
    cognome=dati.pop(0)
    nome=dati.pop(0)
    cf=dati.pop(0)
    #Visualizzazione a video

    return cognome, nome, cf

#Definizione della funzione, nome e attributi
def login(cognome, nome, cf):
    '''Funzione che prende i dati precedentemente acquisiti dalla funzione ask e li rimodella per generare dati di acesso
    login(cognome, nome, cf)
    >>>('bernacci', 'Brnfgd_0', 'bernacci.federica_giusi@picolab.eu')
    '''
    
    #Blocco di funzioni che "pulisce" e modifica i dati in modo da generare username, password e mail congrue ai dati anagrafici
    cognome=cognome.replace(' ', '_').replace("'", "_")
    username=cognome.lower()
    password=((cf[0:6])+"_0").capitalize()
    nome=nome.replace(' ', '_').replace("'", "_")
    mail=cognome.lower()+"."+nome.lower()+"@picolab.eu"
    #Visualizzazione a video

    return username, password, mail