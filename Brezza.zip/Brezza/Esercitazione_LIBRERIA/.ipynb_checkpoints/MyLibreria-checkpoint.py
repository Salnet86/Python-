


def addition(a, b):
    
    somma = a+ b
    print("Valore somma:", somma)