def binario_a_decimale(binario):
return int(binario, 2)

# Esempio di utilizzo
numero_binario = '1010'
numero_decimale = binario_a_decimale(numero_binario)
print(f"Il numero decimale di {numero_binario} è {numero_dec
