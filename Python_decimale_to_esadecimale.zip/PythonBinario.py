# Funzione per convertire un numero decimale in binario
def decimale_a_binario(numero):
return bin(numero)[2:] # Rimuove il prefisso '0b'

# Esempio di utilizzo
numero_decimale = 10
numero_binario = decimale_a_binario(numero_decimale)
print(f"Il numero binario di {numero_decimale} è {numero_binario}")
