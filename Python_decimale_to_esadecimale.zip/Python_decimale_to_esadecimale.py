def esadecimale_a_decimale(esadecimale):
return int(esadecimale, 16)

# Esempio di utilizzo
numero_esadecimale = 'A3F' # Puoi cambiare questo valore con qualsiasi numero esadecimale
numero_decimale = esadecimale_a_decimale(numero_esadecimale)
print(f"Il numero decimale di {numero_esadecimale} è {numero_decimale}")
