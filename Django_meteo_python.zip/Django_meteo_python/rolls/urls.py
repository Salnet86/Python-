from django.urls import path

from .import views



'''
urlpatterns=[

 
  path('rolls/' , views.rolls),


]
'''

'''
app_name = 'rolls'  # Add this line

urlpatterns = [
   path('', views.rolls, name='index'),  # This should work if the rolls function is defined
   path('temperature/', views.temperature_Mas_Min, name='temperature_Mas_Min'),
  

]
'''

from django.urls import path
from . import views  # Ensure you import views

app_name = 'rolls'

urlpatterns = [
    path('', views.rolls, name='index'),
    path('temperature/', views.temperature_Mas_Min, name='temperature_Mas_Min'),
    path('vento/', views.vento, name='vento'),
]
