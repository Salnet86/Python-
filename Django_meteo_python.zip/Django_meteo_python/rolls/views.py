'''

from django.shortcuts import redirect


def rolls(request):
    return  render(request, 'rolls/Hello.html')

'''

from django.shortcuts import render
from flask import send_file
import io
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os
from django.conf import settings

def rolls(request):
    return render(request, 'rolls/index.html')

from django.shortcuts import render
from django.http import HttpResponse
import io
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os
from django.conf import settings
import logging





'''

logger = logging.getLogger(__name__)

def rolls(request):
    return render(request, 'rolls/index.html')

def temperature_Mas_Min(request):
    csv_file_path = os.path.join(settings.BASE_DIR, 'rolls/stazione.csv')

    try:
        df = pd.read_csv(csv_file_path)
    except Exception as e:
        logger.error(f"Error reading CSV file: {e}")
        return HttpResponse(f"Error reading CSV file: {e}", status=500)


    x = df['Temperatura_media']
    y = df['Temperatura_massima']
    
    try:
        fig, ax = plt.subplots(figsize=(10, 5))
        sns.lineplot(x=x, y=y, ax=ax)
        ax.set_title('Temperature massime e minime')
        ax.set_xlabel('Temperatura minima')
        ax.set_ylabel('Temperatura massima')

        img = io.BytesIO()
        fig.savefig(img, format='png')
        img.seek(0)
        
      
        return HttpResponse(img.getvalue(), content_type='image/png')
    except Exception as e:
        logger.error(f"Error generating plot: {e}")
        return HttpResponse(f"Error generating plot: {e}", status=500)
'''


from django.shortcuts import render
from django.http import HttpResponse
import io
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

def rolls(request):
    return render(request, 'rolls/index.html')






def temperature_Mas_Min(request):
    csv_file_path = os.path.join(settings.BASE_DIR, 'rolls/stazione.csv')

    try:
        df = pd.read_csv(csv_file_path)
    except Exception as e:
        logger.error(f"Error reading CSV file: {e}")
        return HttpResponse(f"Error reading CSV file: {e}", status=500)

    x = df['Temperatura_media']
    y = df['Temperatura_massima']
    
    try:
        fig, ax = plt.subplots(figsize=(20, 5))
        sns.lineplot(x=x, y=y, ax=ax)
        ax.set_title('Temperature massime e minime')
        ax.set_xlabel('Temperatura minima')
        ax.set_ylabel('Temperatura massima')

        img = io.BytesIO()
        fig.savefig(img, format='png')
        img.seek(0)
        
        return HttpResponse(img.getvalue(), content_type='image/png')
    except Exception as e:
        logger.error(f"Error generating plot: {e}")
        return HttpResponse(f"Error generating plot: {e}", status=500)








def vento(request):
    csv_file_path = os.path.join(settings.BASE_DIR, 'rolls/stazione.csv')

    try:
        df = pd.read_csv(csv_file_path)
    except Exception as e:
        logger.error(f"Error reading CSV file: {e}")
        return HttpResponse(f"Error reading CSV file: {e}", status=500)

    y = df['Vento Max']
    x = df['Giorno']
    
    try:
        fig, ax = plt.subplots(figsize=(20, 5))
        sns.lineplot(x=x, y=y, ax=ax)
        ax.set_title('Vento [k/m]')
        ax.set_xlabel('Giorni')
        ax.set_ylabel('Vento max [k/m]')
        
        img = io.BytesIO()
        fig.savefig(img, format='png')
        img.seek(0)
        
        return HttpResponse(img.getvalue(), content_type='image/png')
    except Exception as e:
        logger.error(f"Error generating plot: {e}")
        return HttpResponse(f"Error generating plot: {e}", status=500)











