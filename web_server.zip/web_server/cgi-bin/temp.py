import cgi
import io
import base64
import pandas as pd
import matplotlib.pyplot as plt

def create_plot(filename="dati.csv"):
    fileHandler="dati.csv"
    try:
        # Open the CSV file using a context manager
        with open(filename, "r") as fileHandler:
            df = pd.read_csv(fileHandler)

        # Extract humidity and temperature data
        umidita = df['umidita']
        temperatura = df['temperatura']

        # Create a BytesIO buffer
        buffer = io.BytesIO()

        # Create the plot
        plt.figure(figsize=(10, 5))
        plt.plot(umidita, label='Umidità', color='blue')
        plt.plot(temperatura, label='Temperatura', color='red')
        plt.xlabel('Indice')
        plt.ylabel('Valore')
        plt.title('Grafico di Umidità e Temperatura')
        plt.legend()
        plt.grid()
        plt.savefig(buffer, format='png')
        plt.close()  # Close the plot

        # Get the image data from the buffer
        buffer.seek(0)  # Go to the start of the BytesIO buffer
        data_uri = base64.b64encode(buffer.read()).decode('utf-8')

        # Create the img tag
        img_tag = f'<img src="data:image/png;base64,{data_uri}" alt="Grafico di Umidità e Temperatura"/>'

        # Print the HTTP headers and HTML content
        print("Content-type: text/html\n")
        print("<title>Grafico Umidità e Temperatura</title>")
        print("<h1>Benvenuto</h1>")
        print("<h2>Grafico di Umidità e Temperatura</h2>")
        print(img_tag)

    except FileNotFoundError:
        print("Content-type: text/html\n")
        print("<title>Error</title>")
        print("<h1>File Not Found</h1>")
        print("<p>Unable to find the specified CSV file.</p>")
    except Exception as e:
        print("Content-type: text/html\n")
        print("<title>Error</title>")
        print("<h1>An error occurred</h1>")
        print(f"<p>{str(e)}</p>")

# Call the function to create the plot
create_plot()
