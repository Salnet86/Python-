#!/usr/bin/env python3



#python -m http.server 8000 --bind localhost --cgi
#http://localhost:8000/cgi-bin/test.py


'''
import cgi
import io
import base64
import matplotlib.pyplot as plt
import numpy as np

def doit():
    # Generate data
    x = np.linspace(-2, 2, 100)
    y = np.sin(x)

    # Create a BytesIO buffer
    buffer = io.BytesIO()

    # Create the plot
    plt.plot(x, y)
    plt.savefig(buffer, format='png')
    plt.close()  # Close the plot to avoid display issues

    # Get the image data from the buffer
    buffer.seek(0)  # Go to the start of the BytesIO buffer
    data_uri = base64.b64encode(buffer.read()).decode('utf-8')

    # Create the img tag
    img_tag = '<img src="data:image/png;base64,{0}" alt="thisistheplot"/>'.format(data_uri)

    # Print the HTTP headers and HTML content
    print("Content-type: text/html\n")
    print("<title>Primo grafico web server</title>")
    print("<h1>Hello</h1>")
    print("<h1>Primo grafico web server</h1>")
    print(img_tag)

doit()


# chmod +x temp.py
# chmod +x cgi-bin/test.py
#python3  cgi-bin/temp.py
'''

import pandas as pd  
import io
import base64
import matplotlib.pyplot as plt
import numpy as np

df=pd.read_csv('cgi-bin/stazione.csv')

def Temp_Max_Min():
   
   

    media=df['Temperatura_media']
    massima=df['Temperatura_massima']
    buffer = io.BytesIO()
    plt.subplots(figsize=(20,10))
    plt.bar(media,massima,color=['blue','green'])
    plt.xlabel("Temperatura_massima")
    plt.ylabel("Temperatura_media")
    plt.grid()
    plt.title("Temperature [C°]")
    plt.savefig(buffer, format='png') 
    plt.close()  
    buffer.seek(0)  
    data_uri = base64.b64encode(buffer.read()).decode('utf-8')
    img_tag = '<img  src="data:image/png;base64,{0}" alt="thisistheplot"/>'.format(data_uri)
    print("Content-type: text/html\n")
    print("<title>Meteo</title>")
    print("<h1 style='text-align:center' >Temperatura max e min</h1>")
    print(img_tag)




def Vento_max():
   
   

    vento=df['Vento Max']
    giorni=df['Giorno']
   
    buffer = io.BytesIO()

    plt.subplots(figsize=(20,10))
    plt.plot(giorni,vento,color='blue')
    plt.scatter(giorni,vento,color='lime')
    plt.xlabel("Giorni")
    plt.ylabel("Vento Max km/h")
    plt.grid()
    plt.title("Meteo")
    plt.savefig(buffer, format='png')  
    plt.close()  
    buffer.seek(0)  
    data_uri = base64.b64encode(buffer.read()).decode('utf-8')
    img= '<img  src="data:image/png;base64,{0}" alt="thisistheplot"/>'.format(data_uri)
    print("<h1 style='text-align:center' >Vento</h1>")
    print(img)





def Vento_raffica():
   
    raffica=df['Raffica']
    giorni=df['Giorno']
    buffer = io.BytesIO()
    plt.subplots(figsize=(20,10))
    plt.plot(giorni,raffica,color='blue')
    plt.scatter(giorni,raffica,color='lime')
    plt.xlabel("Giorni")
    plt.ylabel("Vento raffica Max km/")
    plt.grid()
    plt.title("Meteo")
    plt.savefig(buffer, format='png')  
    plt.close()  
    buffer.seek(0)  
    data_uri = base64.b64encode(buffer.read()).decode('utf-8')
    img_uno= '<img  src="data:image/png;base64,{0}" alt="thisistheplot"/>'.format(data_uri)
    print("<h1  style='text-align:center'  >Vento raffica </h1>")
    print(img_uno)






def Temp_max_min_umidita():
   
    temp_min=df['Temperatura_minima']
    temp_mass=df['Temperatura_massima']
    temp_med=df['Temperatura_media']
    umidita=df['Umidità']
    buffer = io.BytesIO()
    plt.subplots(figsize=(20,10))
    plt.bar(umidita,temp_min,color='blue')
    plt.bar(umidita,temp_mass,color='lime')
    plt.bar(umidita,temp_med,color='green')
    plt.xlabel("Umidita")
    plt.ylabel("Temperature max,min,med [C°]")
    plt.grid()
    plt.title("Meteo")
    plt.savefig(buffer, format='png')  
    plt.close()  
    buffer.seek(0)  
    data_uri = base64.b64encode(buffer.read()).decode('utf-8')
    img_bar= '<img  src="data:image/png;base64,{0}" alt="thisistheplot"/>'.format(data_uri)
    print("<h1 style='text-align:center' >Temperature umidita </h1>")
    print(img_bar)









Temp_Max_Min()
Vento_max()
Vento_raffica()
Temp_max_min_umidita()