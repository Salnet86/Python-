#!/usr/bin/env python3
'''
print("Content-Type: text/html")  # HTML is following
print()  # Blank line, end of headers
print("<html><body><h1>Hello from test.py!</h1></body></html>")

'''


#python -m http.server 8000 --bind localhost --cgi
#http://localhost:8000/cgi-bin/test.py



import cgi
import io
import base64
import matplotlib.pyplot as plt
import numpy as np

def doit():
    # Generate data
    x = np.linspace(-2, 2, 100)
    y = np.sin(x)

    # Create a BytesIO buffer
    buffer = io.BytesIO()

    # Create the plot
    plt.plot(x, y)
    plt.savefig(buffer, format='png')
    plt.close()  # Close the plot to avoid display issues

    # Get the image data from the buffer
    buffer.seek(0)  # Go to the start of the BytesIO buffer
    data_uri = base64.b64encode(buffer.read()).decode('utf-8')

    # Create the img tag
    img_tag = '<img src="data:image/png;base64,{0}" alt="thisistheplot"/>'.format(data_uri)

    # Print the HTTP headers and HTML content
    print("Content-type: text/html\n")
    print("<title>Primo grafico web server</title>")
    print("<h1>Hello</h1>")
    print("<h1>Primo grafico web server</h1>")
    print(img_tag)

doit()


# chmod +x temp.py
# chmod +x cgi-bin/test.py
#python3  cgi-bin/temp.py
