import cgi
import io
import base64
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

def temperatura():
    # Attempt to read the CSV file
    try:
        df = pd.read_csv("dati.csv")
    except FileNotFoundError:
        print("Content-type: text/html\n")
        print("<h1>Error</h1><p>File not found.</p>")
        return
    except Exception as e:
        print("Content-type: text/html\n")
        print(f"<h1>Error</h1><p>{str(e)}</p>")
        return

    # Check if the required columns are present
    if 'umidita' not in df.columns or 'temperatura' not in df.columns:
        print("Content-type: text/html\n")
        print("<h1>Error</h1><p>Missing required data columns.</p>")
        return

    umidita = df['umidita']
    temperatura = df['temperatura']

    buffer = io.BytesIO()
    plt.plot(temperatura, umidita)
    plt.title('Temperatura vs Umidita')
    plt.xlabel('Temperatura')
    plt.ylabel('Umidita')
    plt.grid(True)
    plt.savefig(buffer, format='png')
    plt.close()

    buffer.seek(0)
    data_uri = base64.b64encode(buffer.read()).decode('utf-8')
    img_tag = f'<img src="data:image/png;base64,{data_uri}" alt="thisistheplot"/>'

    # Print the HTTP headers and HTML content
    print("Content-type: text/html\n")
    print("<html><head><title>Primo grafico web server</title></head><body>")
    print("<h1>Hello</h1>")
    print("<h1>Primo grafico web server</h1>")
    print(img_tag)
    print("</body></html>")

temperatura()
