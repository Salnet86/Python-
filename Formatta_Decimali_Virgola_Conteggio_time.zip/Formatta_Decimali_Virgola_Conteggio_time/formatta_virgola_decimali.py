import time
'''
   PYTHON FORMATTA NUMERI DECIMALI CON LA VIRGOLA 

'''

'''
prezzo1=13.14159

prezzo2=-987.65

prezzo2=12.00

print(f"Prezzo uno e {prezzo1:0.1f}")
print(f"Prezzo due  e {prezzo2:0.2f}")
print(f"Prezzo due  e {prezzo2:0.2f}")
'''
import time
'''
print("Before the sleep statement")
time.sleep(5)
print("After the sleep statement")
'''


n=True
i=0
while n==True:
    i=i+1
    time.sleep(1)
    print(f":0{i:01}",end="\r")
    if i==10:
        n=False