
'''
a,b=1,3

if a==b:
    print(a)
elif a > b:
    print(b)
else:
    print(a+b)
'''
'''
a , b = 6, 6


if a==b:
    print("Il numeri sono uguali  ","valore  di  a",a,"valore  di  b",b)
elif a < b:
    print("I numero b e mmagiore di a :" ,b)
else:
    print("Nessuno numero sono confrontabili somma a + b ", a+b)
'''
'''
Numero=int(input("Inserisci un numero da confrontare"))
Incognita=10

if Incognita< Numero:
    print("Il numero e piu grande dell'incognita " , Numero)
else:
    print(f"L'incognita  {Incognita}    e piu grande  {Numero} ")
'''



'''
 Ricerca Binaria trova il numero in una lista 
'''

Trovato=True
lista=[1,2,35,7,66,33]
l=len(lista)
i=0
x=33
pos=0
while i < l:
    dx=0
    sx=0
    dx=l
    media=int(sx + dx/2)
    if i >= media:
        if lista[i]==x:
            trovato=True
            pos=i
    if media <= i:
        if lista[i]==x:
            trovato=True
            pos=i
    else:
        trovato=False
    i=i+1


if Trovato==True:
    print("Numero torvato   :",lista[pos],"In posizione    :",pos)
else:
    print("Numero non trovatto")





'''

Nome=input("Nome utente :")
Riusltato=int(input("Risultato quiz     :"))

if Riusltato>=6:
    print("Sei sufficente ",Riusltato,"Nome utente",Nome)
elif Riusltato<5:
    print("Sei in sufficente")

    




    