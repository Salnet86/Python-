
Esci=True
while Esci:
    print("------Menu----------------")
    print("1) Crea basi dati")
    print("2) Elenca i soci")
    print("3) Aggiungi un socio")
    print("4) Esci")
    Selezione=input('Inserisci')
    #Esci=True


    if Selezione=="1":
        print("\nCrea basi dati")
        
    elif Selezione=="2":
        print("\nElenca soci")
        
    elif Selezione=="3":
        print("\nInserisci soci")
        
    elif Selezione=="4":
        print("\nSei uscito")
        Esci=False 
        break