
'''

from kivy.app import App
from kivy.uix.button import Button
class PrimaApp(App):
	def build(self):
		return Button(text='Ben venuto Android')
PrimaApp().run()
'''
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button

class CalculatorApp(App):
    def build(self):
        self.operators = ['+', '-', '*', '/']
        self.last_was_operator = False
        
        # Create the main layout
        layout = BoxLayout(orientation='vertical')
        
        # Create the display
        self.result = Label(size_hint_y=None, height='50dp', text='')
        layout.add_widget(self.result)
        
        # Create the buttons
        buttons = [
            ('7', '8', '9', '/'),
            ('4', '5', '6', '*'),
            ('1', '2', '3', '-'),
            ('0', 'CE', '=', '+')
        ]
        
        grid = GridLayout(cols=4)
        for row in buttons:
            for text in row:
                button = Button(text=text)
                button.bind(on_press=self.on_button_press)
                grid.add_widget(button)
                
        layout.add_widget(grid)
        return layout

    def on_button_press(self, instance):
        current = self.result.text
        button_text = instance.text
        
        if button_text == 'CE':
            self.result.text = ''
        elif button_text == '=':
            try:
                self.result.text = str(eval(self.result.text))
            except Exception:
                self.result.text = 'Error'
        else:
            if (self.last_was_operator and button_text in self.operators) or (current == '' and button_text in self.operators):
                return
            current += button_text
            self.result.text = current
            self.last_was_operator = button_text in self.operators

if __name__ == '__main__':
    CalculatorApp().run()
