#!/usr/bin/env python3

import random as rd

def CPU():
   
    print("Content-type: text/html\r\n")
    
   
    print("<html><head><title>Temperature and Humidity</title></head>")
    print("<body>")
    print("<h1 style='text-align:center'>CPU Temperature</h1>")
    
   
    Temperatura_Cpu = rd.randint(30, 90) 
    temp_threshold = 70
    
    if Temperatura_Cpu > temp_threshold:
        print(f'<p style="color:red;">La temperatura CPU ha superato i: {Temperatura_Cpu}°C</p>')
    else:
        print(f'<p style="color:green;">Valore temperatura CPU: {Temperatura_Cpu}°C</p>')
    
    print("</body>")
    print("</html>")

CPU()
