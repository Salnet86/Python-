#!/usr/bin/env python3

import cgi
import cgitb


cgitb.enable()

form = cgi.FieldStorage()

#prendo i valori dalla form
username = form.getvalue("username")
emailaddress = form.getvalue("emailaddress")
password = form.getvalue("password")

print("Content-Type: text/html")
print()  

print("<html>")
print("<head>")
print("<title>Login</title>")
print("</head>")
print("<body>")
print("<h3>Welcome !!!!!!!!!!!!!</h3>")

if username and emailaddress and password:
    print("<p>Username: {}</p>".format(username))
    print("<p>Email Address: {}</p>".format(emailaddress))
    print("<p>Password     : {}</p>".format(password))
else:
    print("<p style='color:red;'>Please not registred</p>")

print("</body>")
print("</html>")
