from django.contrib import admin


#from .models import Perosna
# Register your models here.
#admin.site.register(Perosna)



