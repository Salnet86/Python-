from django.db import models

# Create your models here.
#python3  manage.py  makemigrations 
#pizze/migrations/0001_initial.py
#python3  manage.py  migrate
#python3  manage.py  createsuperuser
from django.db import models

'''
class Perosna(models.Model):
  firstname = models.CharField(max_length=255)
  lastname = models.CharField(max_length=255)
'''
'''

class Studentessa(models.Model):
    nome=models.CharField(max_length=20)
  
    
    
    def __str__(self):
        return f"{self.nome}"



'''






'''
class Ordine(models.Model):
    numero = models.CharField(max_length=50)  # Numero dell'ordine
    data = models.DateField()                 # Data dell'ordine
    cliente = models.CharField(max_length=100)  # Nome del cliente

    def __str__(self):
        return f"Ordine {self.numero} - Cliente: {self.cliente}"

'''   

class Persona(models.Model):
    nome = models.CharField(max_length=100)
    cognome = models.CharField(max_length=100)
    email = models.EmailField(max_length=100, null=True, blank=True)  # Nuovo campo aggiunto

    def __str__(self):
        return f"{self.nome} {self.cognome}  {self.email}"
