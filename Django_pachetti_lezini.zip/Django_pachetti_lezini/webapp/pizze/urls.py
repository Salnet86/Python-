from django.urls import path
from . import views 
from .views import crea_persona, lista_persone, cancella_persona

app_name = 'pizze'

urlpatterns = [
    path('index/', views.index, name='index'), 
    path('crea/', crea_persona, name='crea_persona'),
    path('lista/', lista_persone, name='lista_persone'),  # Ensure this line exists
    path('cancella/', cancella_persona, name='cancella_persona'),
]


'''
from . import views 
from django.views.generic import TemplateView
app_name = 'pizze'

urlpatterns = [
    path('index/', views.index, name='index'), 
    path('crea_persona/', views.crea_persona, name='crea_persona'),
    path('lista_persone/', views.lista_persone, name='lista_persone'),  
    path('cancella/', views.cancella_persona, name='cancella_persona'),
    
]

'''