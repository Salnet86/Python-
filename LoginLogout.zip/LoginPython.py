@app.route('/login', methods=['POST'])
def do_admin_login():
username = request.form['username']
password = request.form['password']

if not username or not password:
flash('Please enter both username and password')
return home()

if username == 'admin' and check_password_hash(hashed_password, password):
session['logged_in'] = True
else:
flash('Wrong password!')

return home()





#--------------------Indirizzo alla pagina 


from flask import url_for

@app.route('/login', methods=['POST'])
def do_admin_login():
if request.form['username'] == 'admin' and check_password_hash(hashed_password, request.form['password']):
session['logged_in'] = True
return redirect(url_for('dashboard')) # Redirige a un dashboard
else:
flash('Wrong password!')













return home()
