from flask import Flask, render_template, request, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(32) # Secure secret key

# Secure session settings
app.config.update(
SESSION_COOKIE_SECURE=True, # Only over HTTPS
SESSION_COOKIE_HTTPONLY=True, # Protect from JavaScript access
SESSION_COOKIE_SAMESITE='Lax' # Prevent CSRF
)

# Mock user database with hashed passwords
users = {
'john': generate_password_hash('password'),
'jane': generate_password_hash('password')
}

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
if request.method == 'POST':
username = request.form['username']
password = request.form['password']
if username in users and check_password_hash(users[username], password):
session['username'] = username
return redirect(url_for('dashboard'))
else:
return render_template('login.html', error='Invalid username or password')
return render_template('login.html')

# Dashboard route
@app.route('/dashboard')
def dashboard():
if 'username' in session:
username = session['username']
return render_template('dashboard.html', username=username)
else:
return redirect(url_for('login'))

# Logout route
@app.route('/logout')
def logout():
session.pop('username', None)
return redirect(url_for('login'))

if __name__ == '__main__':
app.run(ssl_context='adhoc', debug=True) # Enable HTTPS for testing
