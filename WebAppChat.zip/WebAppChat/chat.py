from flask import Flask, render_template, request
from flask_mysqldb import MySQL

app = Flask(__name__)

# Configurazione MySQL
app.config['MYSQL_HOST'] = 'localhost' # Modifica con l'host del tuo MySQL
app.config['MYSQL_USER'] = 'tuo_mysql_utente' # Modifica con il tuo nome utente MySQL
app.config['MYSQL_PASSWORD'] = 'tuo_mysql_password' # Modifica con la tua password MySQL
app.config['MYSQL_DB'] = 'chat_db' # Nome del tuo database

mysql = MySQL(app)

@app.route('/')
def index():
"""Mostra i messaggi sulla pagina HTML."""
cur = mysql.connection.cursor()
cur.execute("SELECT * FROM messages ORDER BY timestamp DESC")
messages = cur.fetchall()
cur.close()

# Passiamo i messaggi alla pagina HTML
return render_template('index.html', messages=messages)

@app.route('/send', methods=['POST'])
def send_message():
"""Permette di inviare un nuovo messaggio tramite un form HTML."""
sender_id = request.form.get('sender_id')
message = request.form.get('message')

if sender_id and message:
cur = mysql.connection.cursor()
cur.execute("INSERT INTO messages (sender_id, message) VALUES (%s, %s)", (sender_id, message))
mysql.connection.commit()
cur.close()

return redirect('/')

if __name__ == '__main__':
app.run(debug=True)
