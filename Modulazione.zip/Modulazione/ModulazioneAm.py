import numpy as np
import matplotlib.pyplot as plt

# Parameters
fs = 200          # Sampling frequency
n = np.arange(0, 2, 1/fs)  # Time vector from 0 to 2 seconds
fc = 100           # Carrier frequency
Ac = 1             # Amplitude of carrier
Fm = 2             # Modulating frequency
Am = 0.5           # Amplitude of modulating signal

# Carrier signal
c = Ac * np.cos(2 * np.pi * fc * n)

# Modulating signal
m = Am * np.sin(2 * np.pi * Fm * n)

# Modulated signal (Amplitude Modulation)
s = c * (1 + m / Ac)

# Plotting
plt.figure(figsize=(10, 6))
plt.plot(n, s)
plt.title('Amplitude Modulated Signal')
plt.xlabel('Time (s)')
plt.ylabel('Amplitude')
plt.grid()
plt.xlim(0, 2)
plt.ylim(-1.5, 1.5)
plt.show()