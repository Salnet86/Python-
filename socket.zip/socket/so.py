import socket 
#In questo caso mi riferisco alla funzione send(), che accetta richieste di tipo bytes-object:
#richiesta = "GET / HTTP/1.1\nHost: www.google.it\n\n"
#print(s.send(richiesta.encode()))


socket_family = socket.AF_INET
socket_type = socket.SOCK_STREAM

s=socket.socket(socket_family, socket_type)

s.connect(("www.google.com",80))
#print(s)
risposta=s.recv(2048)


while len(risposta)>0:
    print(risposta)
    risposta = s.recv(2048)
s.close()


print(s)