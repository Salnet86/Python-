import socket

# Creazione del socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Impostazione dell'indirizzo e della porta
host = '127.0.0.1'  # localhost
port = 12345

# Connessione al server
client_socket.connect((host, port))

# Messaggio da inviare
msg = 'Ciao sto mandano un messaggio!'
client_socket.send(msg.encode())  # Usa encode() per convertire in byte

# Ricevere la risposta
response = client_socket.recv(1024).decode()  # Usa recv() e decode()
print(f'Risposta dal server: {response}')

# Chiudere il socket
client_socket.close()
