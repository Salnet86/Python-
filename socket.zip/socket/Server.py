import socket

s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)


host='127.0.0.1'
porta=12345


s.bind((host, porta))



s.listen(1)

print(f"Il server e in ascolto su {host} sulla porta {porta}")

while True:
    # Accettare una connessione
    client_sock,addr=s.accept()
    print(f'Connessione da {addr}')

    # Ricevere dati dal client

    data=client_sock.recv(1024)
    # Decodifica i byte in stringa
    data=data.decode()
    print(f'Dato ricevuto: {data}')

    risposta="Mesaggio l'ho ricevuto con sucesso"

    client_sock.send(risposta.encode())
    client_sock.close()




