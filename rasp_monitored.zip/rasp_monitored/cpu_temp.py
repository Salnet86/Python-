from flask import Flask, render_template, send_file
import io
import psutil
import matplotlib.pyplot as plt
import pandas as pd

app = Flask(__name__)

@app.route('/index')
def index():
    cpu_usage = int(psutil.cpu_percent(interval=1))
    disk_usage = int(psutil.disk_usage('/').percent)
    memory_usage = int(psutil.virtual_memory().percent)
    return render_template(
        "index.html",
        cpu=cpu_usage,
        disk=disk_usage,
        memoria=memory_usage
    )



@app.route('/disk')
def disk():
    return render_template("disco.html")



@app.route('/tem')
def temperature():
    return render_template("temperatura.html")



@app.route('/CPU')
def cpu_temperature():
    try:
        # Get CPU temperatures
        temps = psutil.sensors_temperatures()
        cpu_temps = temps.get('coretemp', [])

        # Check if CPU temperatures are available
        if not cpu_temps:
            return "No CPU temperature data available.", 404

        # Extract current temperatures and CPU usage
        temperature_add = [temp.current for temp in cpu_temps]
        cpu_usage = psutil.cpu_percent(interval=1)

        # Create a bar plot for CPU temperatures
        fig, ax = plt.subplots(figsize=(10, 5))
        ax.bar(range(len(temperature_add)), temperature_add, color='lime', label='CPU Temperature')
        ax.set_xlabel('Core')
        ax.set_ylabel('CPU Temperature (°C)', color='blue')
        ax.set_title('CPU Temperature Monitoring')
        ax.grid()
        ax.legend()

        # Save the plot to a BytesIO object
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plt.close(fig)

        # Return the image file as a response
        return send_file(img, mimetype='image/png')
    
    except Exception as e:
        return str(e), 500  # Return a server error with the exception message






@app.route('/disco', endpoint='disk_usage')
def disk_usage():
    try:
        memory_usage = psutil.virtual_memory().percent
        disk_usage = psutil.disk_usage('/').percent
        
        y = [memory_usage, disk_usage]
        mylabels = ["Memoria", "Dischi usati"]
        
        fig, ax = plt.subplots(figsize=(10, 5))
        ax.pie(y, labels=mylabels, startangle=90, autopct='%1.1f%%')
        ax.axis('equal') 
        ax.set_title('Utilizzo di Memoria e Disco')
        ax.grid()

        # Save the plot to a BytesIO object
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plt.close(fig)

        # Return the image file as a response
        return send_file(img, mimetype='image/png')

    except Exception as e:
        return str(e), 500








if __name__ == '__main__':
    app.run(debug=True)











