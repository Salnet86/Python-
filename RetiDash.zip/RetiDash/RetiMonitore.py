import pandas as pd
import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import psutil

app = dash.Dash(__name__)

cpu_value = []
memoria_value = []
cpu_temp_value = []
cont=[]



cpu_usage = psutil.cpu_percent(interval=1)
disk_usage = psutil.disk_usage('/').percent
memory_usage = psutil.virtual_memory().percent



data = pd.DataFrame([{
    "CPU": f"{cpu_usage}%",
    "DISK": f"{disk_usage}%",
    "MEMORIA": f"{memory_usage}%"
}])


colors = {
    'background': '#111111',
    'text': 'green'
}

app.layout = html.Div(style={'backgroundColor': colors['background']}, children=[
    html.H1("Rete monitoraggio", style={'text-align': 'center', 'color': colors['text']}),

    dcc.Graph(id='bar-plot'),
    dcc.Graph(id='temp-plot'),
    dcc.Graph(id='conteggi'),
   

    dcc.Interval(
        id='interval-component',
        interval=5*1000,  # Update every 5 seconds
        n_intervals=0
    ),

   dash.dash_table.DataTable(
        data=data.to_dict('records'),
        columns=[{"name": i, "id": i} for i in data.columns],
    )
   
   
])

@app.callback(
    [Output('bar-plot', 'figure'), Output('temp-plot', 'figure'),Output('conteggi', 'figure')],
    [Input('interval-component', 'n_intervals')]
)








def update_metrics(n):
 


    cpu = psutil.cpu_percent(interval=1)
    CONTEGGI=psutil.cpu_count()
    memoria = psutil.virtual_memory().percent
    cpu_value.append(cpu)
    memoria_value.append(memoria)
    temps = psutil.sensors_temperatures()
    temp_key = next(iter(temps))  
    cpu_temp = temps[temp_key][0].current  
    cpu_temp_value.append(cpu_temp)
    cont.append(CONTEGGI)
    
    bar_plot = {
        'data': [
            {'x': list(range(len(cpu_value))), 'y': cpu_value, 'type': 'bar', 'name': 'CPU'},
            {'x': list(range(len(memoria_value))), 'y': memoria_value, 'type': 'bar', 'name': 'Memory'},
        ],
        'layout': {
            'title': 'CPU and Memory Usage [%]',
            'plot_bgcolor': colors['background'],
            'paper_bgcolor': colors['background'],
            'font': {'color': colors['text']}
        }
    }






    temp_plot = {
        'data': [
            {'x': list(range(len(cpu_temp_value))), 'y': cpu_temp_value, 'type': 'scatter', 'mode': 'lines+markers', 'name': 'CPU Temp'}
        ],
        'layout': {
            'title': 'CPU Temperature [°C]',
            'plot_bgcolor': colors['background'],
            'paper_bgcolor': colors['background'],
            'font': {'color': colors['text']}
        }
    } 

    
    
    conteggi = {
        'data': [
              {'x':cpu_value , 'y': cpu_value, 'type': 'bar', 'name': 'cpu'},
              {'x':cont , 'y': cont, 'type': 'bar', 'name': 'conteggi'}
        ],
        'layout': {
            'title': 'Conteggi CPU',
            'plot_bgcolor': colors['background'],
            'paper_bgcolor': colors['background'],
            'font': {'color': colors['text']}
        }
    } 

     
   




    return bar_plot, temp_plot,conteggi

if __name__ == '__main__':
    app.run_server(debug=True)
