#!/usr/bin/env python3


#python3 cgi-bin/test.py
#python -m http.server 8000 --bind localhost --cgi
#http://localhost:8000/cgi-bin/test.py



from http.cookies import SimpleCookie
import pandas as pd  
import io
import base64
import matplotlib.pyplot as plt
import numpy as np
import os


df = pd.read_csv('cgi-bin/stazione.csv')

def Temp_Max_Min():
    media = df['Temperatura_media']
    massima = df['Temperatura_massima']
    
    buffer = io.BytesIO()
    plt.subplots(figsize=(20,10))
    plt.bar(media, massima, color=['blue', 'green'])
    plt.xlabel("Temperatura_massima")
    plt.ylabel("Temperatura_media")
    plt.grid()
    plt.title("Temperature [C°]")
    plt.savefig(buffer, format='png') 
    plt.close()  
    buffer.seek(0)
    
    data_uri = base64.b64encode(buffer.read()).decode('utf-8')
    img_tag = f'<img src="data:image/png;base64,{data_uri}" alt="thisistheplot"/>'
    
    print("Content-type: text/html\n")
    print("<title>Meteo</title>")
    print("<h1 style='text-align:center'>Temperatura max e min</h1>")
    print(img_tag)

def Vento_max():
    vento = df['Vento Max']
    giorni = df['Giorno']
    
    buffer = io.BytesIO()
    plt.subplots(figsize=(20,10))
    plt.plot(giorni, vento, color='blue')
    plt.scatter(giorni, vento, color='lime')
    plt.xlabel("Giorni")
    plt.ylabel("Vento Max km/h")
    plt.grid()
    plt.title("Meteo")
    plt.savefig(buffer, format='png')  
    plt.close()  
    buffer.seek(0)
    
    data_uri = base64.b64encode(buffer.read()).decode('utf-8')
    img = f'<img src="data:image/png;base64,{data_uri}" alt="thisistheplot"/>'
    
    print("<h1 style='text-align:center'>Vento</h1>")
    print(img)

def Vento_raffica():
    raffica = df['Raffica']
    giorni = df['Giorno']
    
    buffer = io.BytesIO()
    plt.subplots(figsize=(20,10))
    plt.plot(giorni, raffica, color='blue')
    plt.scatter(giorni, raffica, color='lime')
    plt.xlabel("Giorni")
    plt.ylabel("Vento raffica Max km/h")
    plt.grid()
    plt.title("Meteo")
    plt.savefig(buffer, format='png')  
    plt.close()  
    buffer.seek(0)
    
    data_uri = base64.b64encode(buffer.read()).decode('utf-8')
    img_uno = f'<img src="data:image/png;base64,{data_uri}" alt="thisistheplot"/>'
    
    print("<h1 style='text-align:center'>Vento raffica</h1>")
    print(img_uno)

def Temp_max_min_umidita():
    temp_min = df['Temperatura_minima']
    temp_mass = df['Temperatura_massima']
    temp_med = df['Temperatura_media']
    umidita = df['Umidità']
    
    buffer = io.BytesIO()
    plt.subplots(figsize=(20,10))
    plt.bar(umidita, temp_min, color='blue', label='Temp Min')
    plt.bar(umidita, temp_mass, color='lime', label='Temp Mass')
    plt.bar(umidita, temp_med, color='green', label='Temp Med')
    plt.xlabel("Umidità")
    plt.ylabel("Temperature max, min, med [C°]")
    plt.grid()
    plt.title("Meteo")
    plt.legend()
    plt.savefig(buffer, format='png')  
    plt.close()  
    buffer.seek(0)
    
    data_uri = base64.b64encode(buffer.read()).decode('utf-8')
    img_bar = f'<img src="data:image/png;base64,{data_uri}" alt="thisistheplot"/>'
    
    print("<h1 style='text-align:center'>Temperature e umidita</h1>")
    print(img_bar)



def Tabella():
    cookie = SimpleCookie(os.environ.get('HTTP_COOKIE', ''))
    visits = int(cookie.get('visits').value) if cookie.get('visits') else 1
    cookie['visits'] = visits + 1

    print("<h1 style='text-align:center'>Dati Meteo 2003</h1>")
    print("<table style='margin:auto; '><tr><th>Giorno</th><th>Vento Max</th><th>Raffica</th><th>Temp Min</th><th>Temp Media</th><th>Temp Max</th><th>Umidita</th></tr>")
    
    for index, row in df.iterrows():
        print(f"<tr><td>{row['Giorno']}</td><td>{row['Vento Max']}</td><td>{row['Raffica']}</td><td>{row['Temperatura_minima']}</td><td>{row['Temperatura_media']}</td><td>{row['Temperatura_massima']}</td><td>{row['Umidità']}</td></tr>")
        
    print("</table>")


Temp_Max_Min()
Vento_max()
Vento_raffica()
Temp_max_min_umidita()
Tabella()


