import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd

# Create a Dash application
app = dash.Dash(__name__)

# Sample data
df = pd.read_csv('stazione.csv')

# Define a color dictionary
colors = {
    'background': '#111111',
    'text': 'green'
}

# Define the layout of the app
 
app.layout =html.Div(style={'backgroundColor': colors['background']}, children=[
    html.H1("Stazione Meteo",style={'text-align':'center','color':'green'}),
    html.H2("Progetto Platania Salvatore",style={'text-align':'center','color':'green'}),
 
    
      dcc.Graph(
        id='scatter-plot',
        figure={
            'data': [
                {'x': df['Giorno'], 'y': df['Vento Max'], 'type': 'scatter', 'mode': 'markers', 'name': 'Scatter Plot'},
            ],
            'layout': {
                'title': 'Vento [km/h]',
                'plot_bgcolor': colors['background'],
                'paper_bgcolor': colors['background'],
                'font': {'color': colors['text']}
            }
        }
    ),

    # Bar Plot
    dcc.Graph(
        id='temperature-bar-plot',
        figure={
            'data': [
                {'x': df['Temperatura_massima'], 'y': df['Temperatura_minima'], 'type': 'bar', 'name': 'Bar Plot'},
            ],
            'layout': {
                'title': 'Temperatura [°C]',
                'plot_bgcolor': colors['background'],
                'paper_bgcolor': colors['background'],
                'font': {'color': colors['text']}
            }
        }
    ),

    # Line Plot
    dcc.Graph(
        id='line-plot',
        figure={
            'data': [
                {'x': df['Giorno'], 'y': df['Raffica'], 'type': 'line', 'name': 'Line Plot'},
            ],
            'layout': {
                'title': 'Raffica di Vento [km/h]',
                'plot_bgcolor': colors['background'],
                'paper_bgcolor': colors['background'],
                'font': {'color': colors['text']}
            }
        }
    ),



    dcc.Graph(
        id='Temp-plot',
        figure={
            'data': [
                {'x': df['Giorno'], 'y': df['Temperatura_media'], 'type': 'line', 'name': 'Line Plot'},
              
            ],
            'layout': {
                'title': 'Temperatura media [C°]',
                'plot_bgcolor': colors['background'],
                'paper_bgcolor': colors['background'],
                'font': {'color': colors['text']}
            }
        }
    ),
    dcc.Graph(
        id='TempVentoPrecipitazioni-plot',
        figure={
            'data': [
                {'x': df['Precip.'], 'y':df['Vento Max'], 'type': 'line', 'name': 'VentoMax [km]'},
                {'x': df['Precip.'], 'y':df['Raffica'], 'type': 'line', 'name': 'VentoRaffica [km]'},
                {'x': df['Precip.'], 'y':df['Umidità'], 'type': 'line', 'name': 'Umidita %'},
                {'x': df['Precip.'], 'y':df['Temperatura_minima'], 'type': 'line', 'name': 'TempMin [C°]'},
                {'x': df['Precip.'], 'y':df['Temperatura_massima'], 'type': 'line', 'name': 'TempMax [C°]'},
                {'x': df['Precip.'], 'y':df['Temperatura_media'], 'type': 'line', 'name': 'TempMed [C°]'},
              
            ],
            'layout': {
                'title': 'Precipitazioni , vento , raffica , temperature , umidità',
                'plot_bgcolor': colors['background'],
                'paper_bgcolor': colors['background'],
                'font': {'color': colors['text']}
            }
        }
    ),


    dash.dash_table.DataTable(data=df.to_dict('records'),columns=[{"name": i, "id": i} for i in df])
   









])

# Run the Dash app
if __name__ == '__main__':
    app.run_server(debug=True)


#----------------------RUN PYTHON APP.PY INDIRIZZO http://127.0.0.1:8050/
#PIP INSTALL DASH


