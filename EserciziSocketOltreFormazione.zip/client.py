import socket

# Crea il socket del client
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('localhost', 12345))

while True:
    # Chiede all'utente di inserire un messaggio
    message = input("Inserisci il messaggio: ").strip()
    if message:
        client_socket.send(message.encode('utf-8'))

    # Riceve e stampa i messaggi dal server
    message = client_socket.recv(1024)
    if message:
        print(f"Messaggio ricevuto: {message.decode('utf-8')}")
