import socket
import select

# Crea il socket del server
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('localhost', 12345))
server_socket.listen(5)
server_socket.setblocking(False)

clienti = []

while True:
    # Usa select per monitorare i socket
    leggibile, _, _ = select.select([server_socket] + clienti, [], [])

    for s in leggibile:
        if s == server_socket:
            # Nuovo client si connette
            client_socket, _ = server_socket.accept()
            client_socket.setblocking(False)
            clienti.append(client_socket)
        else:
            # Gestisce i messaggi dei client
            messaggio = s.recv(1024)
            if messaggio:
                print(f"Messaggio ricevuto: {messaggio.decode('utf-8')}")
                # Invia il messaggio a tutti gli altri client
                for client in clienti:
                    if client != s:
                        client.send(messaggio)
            else:
                # Client disconnesso
                clienti.remove(s)
                s.close()
