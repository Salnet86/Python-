
#comentare il programma

'''
 comento per piu testo 

'''





Nome=input("Scrivi il tuo nome con lettara maiuscola")

Cognome=input("Scrivi il tuo cognome con la lettera maiuscola ")

c=Nome+'  '+Cognome

print("Ben venuto :      ", c)