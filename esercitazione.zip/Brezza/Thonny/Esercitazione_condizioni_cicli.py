'''
1) Prima esercitazione python
Programmare in Python: controllo del flusso esercizi
Esercizi ciclo if-elif-else, applicazioni python:

ES_if_01:, scrivere una applicazione che:
chiede il nome,
chiede il risultato del quiz,
se il risultato del quiz è maggiore o uguale a 6/10
stampa 'Sei sufficiente'
se il risultato del quiz è minore di 5/10
stampa 'devi rivedere il capitolo strumeti di base'
stampa 'un ripasso potrebbe esserti utile'

'''


'''
nome = input("Inserisci il tuo nome: ")
quiz = float(input("Inserisci il voto della verifica: "))

if quiz >= 6:
    print("Sei sufficiente")
elif quiz <= 5:
    print("Devi rivedere il capitolo strumeti di base")
    print("Un ripasso potrebbe esserti utile")
'''


'''
 Esercizi ciclo for, applicazioni python:
 ES_for_01: definire un elenco di nomi di giorni feriali, compilare una lista e presentare a monitor la lista dei giorni feriali. 

'''


'''
Feriali=['Lunedì','Martedì','Mercoledì','Giovedì','Venerdì']
i=0
while i<=len(Feriali)-1:
    print(Feriali[i])
    i+=1
'''




Feriali=['Lunedì','Martedì','Mercoledì','Giovedì','Venerdì']

for i in range(len(Feriali)):
    print(Feriali[i])









