import numpy as np
import matplotlib.pyplot as plt
'''
n=int(input("inserisci un numero per la piramide   "))

for i in range(n):
    for j in range(n - i):
        print(" ",end="")
    for k in range(2 * i -1):
        print("*",end="")
    print()
    
'''

def funzione(x):
    return 4*(x-1.2)**2





r = 0.0001
x = np.arange(0, 2, r)
y = funzione(x)
plt.plot(x,y)
plt.show()