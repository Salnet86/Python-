risultato = None

def somma(a,b):
    return a+b



def sottazione(a,b):
    
    return (a-b)




def moltiplicazione(a,b):
    
    return (a*b)



def  divisione(a,b):
    
    return (a/b)


def StampaRisultato(operazione):
    
    match(operazione):
       
        case "+":
            risultato=somma(a,b)
        case "-":
            risultato=sottrazione(a,b)
        case "*":
            risultato=moltiplicazione(a,b)
        case "/":
            risultato=divisione(a,b)
            
                
            
            
    print(f'Valore del risultato e:    {risultato}')





a=int(input("inserisci il primo valore    "))
operazione=input("Scegli l'operazione da fare +,-,*,/   ")
b=int(input("inserisci il secondo valore  "))
StampaRisultato(operazione)







