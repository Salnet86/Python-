
#Conversione temperatura e converti celsius a fahrenheit
Temperatura=float(input("Inserisci il valore di temperatura   "))
TempF=(1.8*Temperatura+32)
print(f"Valore di temperatura {TempF}°F")
