COGNOME, Nome, CF = 'paperino', 'paolino', 'pprpln34b18e682k'
print(COGNOME.upper(),Nome.capitalize(),CF.upper())
scheda = [COGNOME.upper(),Nome.capitalize(),CF.upper()]
