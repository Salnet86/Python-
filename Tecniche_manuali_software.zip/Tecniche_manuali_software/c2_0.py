string1 = "Linux"
string2 = "Hint"
joined_string = string1 + string2
print(joined_string)
